import { saludar } from './saludo.js';
saludar('Francco');