export function saludar(nombre) {
  console.log(`Hola ${nombre}`);
}